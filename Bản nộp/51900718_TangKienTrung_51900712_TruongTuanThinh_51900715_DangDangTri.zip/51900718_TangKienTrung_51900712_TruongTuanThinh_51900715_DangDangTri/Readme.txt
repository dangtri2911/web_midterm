# Advance web midterm

### 1) Start project 

-   Run these command to start project

```
    npm install 
    npm start
```

-   Your application should have run in http://localhost:4000

### 2) Feature

-   Default account to test:

    +   user1/123456

    +   user2/123456

    +   user3/123456

### 3) Team member

-   This project is contributed by:

1) DANG DANG TRI - 51900715

2) TANG KIEN TRUNG – 51900718

3) TRUONG TUAN THINH – 51900712
